from distutils.core import setup

setup(
    name="testprojlib",
    packages=['main', 'main.utils'],
    url='https://github.com/maksim-dzhigil/setup_testing'
)